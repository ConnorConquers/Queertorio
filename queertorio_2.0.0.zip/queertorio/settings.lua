data:extend({
    {
      type = "bool-setting",
      name = "my_custom_feature_enabled",
      setting_type = "startup",
      default_value = false,
      order = "a",  -- Sorting order in the settings menu, "a" will appear before "b".
      localised_name = "Identify As Queer",
      localised_description = "Toggle for an LGBQT+ identity. This has no effect on the game but you'll know what's up."
    },
    {
      type = "string-setting",
      name = "my_dropdown_setting",
      setting_type = "startup",
      default_value = "They/Them",
      allowed_values = {"They/Them", "He/Him", "She/Her", "It/Its", "Ze/Zir", "Xe/Xem", "Fae/Faer", "Ey/Em", "None"},
      order = "b",
      localised_name = "Preferred Pronoun",
      localised_description = "Select your pronoun. The bugs don't talk to you, so this value is never read."
    }
  })
  